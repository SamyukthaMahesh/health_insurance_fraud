For this Project, all the four Datasets and the Juypter Notebook need to be in the same folder.

Rename the following files as such:
	1. Train_Beneficiarydata-1542865627584.csv to BeneficiaryData.csv
	2. Train_Inpatientdata-1542865627584 to InpatientData.csv
	3. Train_Outpatientdata-1542865627584 to OutpatientData.csv
	4. Train-1542865627584 to ProviderData.csv

The project was executed in the following configurations:
Processor : Intel(R) Core(TM) i7-9750H CPU @ 2.60GHz   2.59 GHz
Installed RAM : 8.00 GB
